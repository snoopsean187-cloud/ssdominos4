package com.example.domino4

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.concurrent.thread

const val PORT = 8765
const val SERVICE_TYPE = "_domino4._tcp."

fun localIp(): String? = runCatching {
    NetworkInterface.getNetworkInterfaces().toList()
        .flatMap { it.inetAddresses.toList() }
        .firstOrNull { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }
        ?.hostAddress
}.getOrNull()

/** Serveur autoritaire : tourne sur le téléphone de l'hôte. */
class GameServer {
    private var serverSocket: ServerSocket? = null
    private val clients = mutableListOf<ClientConn>()
    private var game: DominoGame? = null
    private val wins = IntArray(4)

    class ClientConn(val socket: Socket, val name: String) {
        private val out = PrintWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8), true)
        @Synchronized fun send(o: JSONObject) { out.println(o.toString()) }
        fun close() { runCatching { socket.close() } }
    }

    fun start() {
        val ss = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT)) }
        serverSocket = ss
        thread(isDaemon = true) {
            try { while (true) listen(ss.accept()) } catch (_: Exception) {}
        }
    }

    @Synchronized fun stop() {
        runCatching { serverSocket?.close() }
        clients.forEach { it.close() }
        clients.clear(); game = null; wins.fill(0)
    }

    private fun listen(s: Socket) = thread(isDaemon = true) {
        var conn: ClientConn? = null
        try {
            val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            while (true) {
                val line = r.readLine() ?: break
                conn = onMessage(s, conn, JSONObject(line))
            }
        } catch (_: Exception) {}
        onDisconnect(conn, s)
    }

    @Synchronized private fun onMessage(s: Socket, c: ClientConn?, m: JSONObject): ClientConn? {
        when (m.getString("t")) {
            "join" -> {
                if (c != null) return c
                if (game != null || clients.size >= 4) {
                    runCatching {
                        PrintWriter(s.getOutputStream(), true)
                            .println(JSONObject().put("t", "error").put("msg", "Partie complète ou déjà commencée").toString())
                        s.close()
                    }
                    return null
                }
                val nc = ClientConn(s, m.optString("name", "Joueur").trim().take(14).ifEmpty { "Joueur" })
                clients.add(nc)
                broadcastLobby()
                return nc
            }
            "start", "again" -> {
                val g = game
                if (c != null && clients.indexOf(c) == 0 && clients.size == 4 && (g == null || g.over)) {
                    game = DominoGame(clients.map { it.name })
                    broadcastState()
                }
            }
            "play" -> {
                val g = game
                if (c != null && g != null) {
                    val a = m.getJSONArray("tile")
                    val ok = g.play(clients.indexOf(c), Tile(a.getInt(0), a.getInt(1)), m.getString("side")[0])
                    if (ok) {
                        if (g.over) wins[g.winner]++
                        broadcastState()
                    }
                }
            }
        }
        return c
    }

    @Synchronized private fun onDisconnect(c: ClientConn?, s: Socket) {
        runCatching { s.close() }
        if (c == null || c !in clients) return
        clients.remove(c)
        if (game != null) {
            val msg = JSONObject().put("t", "error")
                .put("msg", "${c.name} s'est déconnecté : la partie est terminée.")
            clients.forEach { it.send(msg); it.close() }
            clients.clear(); game = null; wins.fill(0)
        } else broadcastLobby()
    }

    private fun broadcastLobby() {
        val names = JSONArray(clients.map { it.name })
        clients.forEachIndexed { i, c ->
            c.send(JSONObject().put("t", "lobby").put("names", names).put("you", i))
        }
    }

    private fun broadcastState() {
        val g = game ?: return
        clients.forEachIndexed { i, c -> c.send(g.stateFor(i, wins)) }
    }
}

/** Client : chaque téléphone (y compris celui de l'hôte, via 127.0.0.1). */
class GameClient(
    private val onMsg: (JSONObject) -> Unit,
    private val onClosed: (String) -> Unit,
) {
    private var socket: Socket? = null
    private var out: PrintWriter? = null
    private val sender = Executors.newSingleThreadExecutor()
    @Volatile private var closing = false

    fun connect(host: String, name: String) {
        thread(isDaemon = true) {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, PORT), 5000)
                socket = s
                out = PrintWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8), true)
                send(JSONObject().put("t", "join").put("name", name))
                val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                while (true) {
                    val line = r.readLine() ?: break
                    onMsg(JSONObject(line))
                }
                if (!closing) onClosed("Connexion perdue avec l'hôte")
            } catch (e: Exception) {
                if (!closing) onClosed("Connexion impossible : ${e.message}")
            }
        }
    }

    fun send(o: JSONObject) {
        sender.execute { out?.println(o.toString()) }
    }

    fun close() {
        closing = true
        runCatching { socket?.close() }
        sender.shutdown()
    }
}

/** Découverte automatique des parties sur le Wi-Fi (NSD / mDNS). */
@Suppress("DEPRECATION")
class Discovery(context: Context) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null
    private val queue = java.util.ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var onFound: ((String, String) -> Unit)? = null

    fun register(name: String) {
        unregister()
        val info = NsdServiceInfo().apply {
            serviceName = "Domino4-$name"; serviceType = SERVICE_TYPE; port = PORT
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onRegistrationFailed(i: NsdServiceInfo, c: Int) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, c: Int) {}
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
        }
        reg = l
        runCatching { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l) }
    }

    fun unregister() {
        reg?.let { r -> runCatching { nsd.unregisterService(r) } }
        reg = null
    }

    fun discover(cb: (String, String) -> Unit) {
        stopDiscovery()
        onFound = cb
        val l = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(t: String, c: Int) {}
            override fun onStopDiscoveryFailed(t: String, c: Int) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(i: NsdServiceInfo) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                if (i.serviceName.startsWith("Domino4-")) {
                    synchronized(this@Discovery) { queue.add(i) }
                    next()
                }
            }
        }
        disc = l
        runCatching { nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l) }
    }

    fun stopDiscovery() {
        disc?.let { d -> runCatching { nsd.stopServiceDiscovery(d) } }
        disc = null
        synchronized(this) { queue.clear(); resolving = false }
    }

    @Synchronized private fun next() {
        if (resolving) return
        val s = queue.poll() ?: return
        resolving = true
        nsd.resolveService(s, object : NsdManager.ResolveListener {
            override fun onResolveFailed(i: NsdServiceInfo, c: Int) = done()
            override fun onServiceResolved(i: NsdServiceInfo) {
                val h = i.host?.hostAddress
                if (h != null && !h.contains(':')) onFound?.invoke(i.serviceName.removePrefix("Domino4-"), h)
                done()
            }
        })
    }

    private fun done() {
        synchronized(this) { resolving = false }
        next()
    }
}
