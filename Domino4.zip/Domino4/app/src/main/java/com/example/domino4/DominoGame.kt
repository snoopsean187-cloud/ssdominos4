package com.example.domino4

import org.json.JSONArray
import org.json.JSONObject

data class Tile(val a: Int, val b: Int) {
    val pips get() = a + b
    fun flipped() = Tile(b, a)
}

/** Logique du jeu (double-six, 4 joueurs, 7 dominos chacun). Le double 6 ouvre. */
class DominoGame(val names: List<String>) {
    val hands = List(4) { mutableListOf<Tile>() }
    val board = ArrayDeque<Tile>()
    var turn = 0
        private set
    var over = false
        private set
    var winner = -1
        private set
    var message = ""
        private set

    init {
        val all = buildList { for (x in 0..6) for (y in x..6) add(Tile(x, y)) }.shuffled()
        for (p in 0..3) hands[p].addAll(all.subList(p * 7, p * 7 + 7))
        turn = hands.indexOfFirst { Tile(6, 6) in it }
        message = "${names[turn]} commence avec le double 6"
    }

    private val left get() = board.first().a
    private val right get() = board.last().b

    fun canPlay(t: Tile, side: Char): Boolean {
        if (board.isEmpty()) return t == Tile(6, 6)
        return if (side == 'L') t.a == left || t.b == left else t.a == right || t.b == right
    }

    private fun hasMove(p: Int) = hands[p].any { canPlay(it, 'L') || canPlay(it, 'R') }

    fun play(p: Int, t: Tile, side: Char): Boolean {
        if (over || p != turn) return false
        val real = hands[p].firstOrNull { it == t || it == t.flipped() } ?: return false
        if (!canPlay(real, side)) return false
        when {
            board.isEmpty() -> board.addLast(real)
            side == 'L' -> board.addFirst(if (real.b == left) real else real.flipped())
            else -> board.addLast(if (real.a == right) real else real.flipped())
        }
        hands[p].remove(real)
        if (hands[p].isEmpty()) {
            over = true; winner = p
            message = "${names[p]} a gagné la manche !"
            return true
        }
        advance()
        return true
    }

    private fun advance() {
        val passers = mutableListOf<String>()
        repeat(4) {
            turn = (turn + 1) % 4
            if (hasMove(turn)) {
                val pre = if (passers.isEmpty()) "" else
                    passers.joinToString(", ") + (if (passers.size > 1) " passent. " else " passe. ")
                message = pre + "Tour de ${names[turn]}"
                return
            }
            passers.add(names[turn])
        }
        over = true
        val pts = hands.map { h -> h.sumOf { it.pips } }
        winner = pts.indexOf(pts.min())
        message = "Jeu bloqué ! ${names[winner]} gagne avec ${pts[winner]} points"
    }

    fun stateFor(p: Int, wins: IntArray): JSONObject {
        fun tiles(l: List<Tile>) = JSONArray(l.map { JSONArray(listOf(it.a, it.b)) })
        return JSONObject()
            .put("t", "state").put("you", p)
            .put("names", JSONArray(names))
            .put("hand", tiles(hands[p]))
            .put("board", tiles(board.toList()))
            .put("counts", JSONArray(hands.map { it.size }))
            .put("turn", turn).put("over", over).put("winner", winner)
            .put("msg", message)
            .put("wins", JSONArray(wins.toList()))
    }
}
