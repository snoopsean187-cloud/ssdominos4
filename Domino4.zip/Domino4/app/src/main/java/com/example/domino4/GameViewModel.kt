package com.example.domino4

import android.app.Application
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

enum class Screen { MENU, LOBBY, GAME }

data class GameState(
    val you: Int, val names: List<String>, val hand: List<Tile>, val board: List<Tile>,
    val counts: List<Int>, val turn: Int, val over: Boolean, val winner: Int,
    val msg: String, val wins: List<Int>,
)

private fun JSONArray.ints() = (0 until length()).map { getInt(it) }
private fun JSONArray.strs() = (0 until length()).map { getString(it) }
private fun JSONArray.tiles() = (0 until length()).map { val t = getJSONArray(it); Tile(t.getInt(0), t.getInt(1)) }

class GameViewModel(app: Application) : AndroidViewModel(app) {
    var screen by mutableStateOf(Screen.MENU)
    var name by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var isHost by mutableStateOf(false)
    var hostIp by mutableStateOf<String?>(null)
    var lobbyNames by mutableStateOf(listOf<String>())
    var st by mutableStateOf<GameState?>(null)
    val found = mutableStateListOf<Pair<String, String>>()

    private val main = Handler(Looper.getMainLooper())
    private val disc = Discovery(app)
    private var server: GameServer? = null
    private var client: GameClient? = null

    private fun ui(f: () -> Unit) { main.post { f() } }

    fun host() {
        if (name.isBlank()) { error = "Entre ton prénom"; return }
        error = null; isHost = true
        val n = name.trim()
        thread {
            try {
                val s = GameServer(); s.start(); server = s
                ui { hostIp = localIp(); disc.register(n); connect("127.0.0.1") }
            } catch (e: Exception) {
                ui { isHost = false; error = "Impossible de créer la partie : ${e.message}" }
            }
        }
    }

    fun startSearch() {
        found.clear()
        disc.discover { label, host ->
            ui { if (found.none { it.second == host }) found.add(label to host) }
        }
    }

    fun join(host: String) {
        if (name.isBlank()) { error = "Entre ton prénom"; return }
        if (host.isBlank()) return
        error = null
        connect(host)
    }

    private fun connect(host: String) {
        disc.stopDiscovery()
        val c = GameClient({ m -> ui { onMessage(m) } }, { why -> ui { onClosed(why) } })
        client = c
        c.connect(host, name.trim())
    }

    private fun onMessage(m: JSONObject) {
        when (m.getString("t")) {
            "lobby" -> { lobbyNames = m.getJSONArray("names").strs(); st = null; screen = Screen.LOBBY }
            "state" -> {
                st = GameState(
                    m.getInt("you"), m.getJSONArray("names").strs(), m.getJSONArray("hand").tiles(),
                    m.getJSONArray("board").tiles(), m.getJSONArray("counts").ints(), m.getInt("turn"),
                    m.getBoolean("over"), m.getInt("winner"), m.getString("msg"), m.getJSONArray("wins").ints(),
                )
                screen = Screen.GAME
            }
            "error" -> error = m.optString("msg")
        }
    }

    private fun onClosed(why: String) {
        val e = error ?: why
        cleanup()
        error = e
        screen = Screen.MENU
    }

    fun leave() { cleanup(); error = null; screen = Screen.MENU }

    private fun cleanup() {
        client?.close(); client = null
        server?.stop(); server = null
        disc.unregister(); disc.stopDiscovery()
        st = null; isHost = false; hostIp = null; lobbyNames = emptyList(); found.clear()
    }

    fun startGame() { client?.send(JSONObject().put("t", "start")) }
    fun again() { client?.send(JSONObject().put("t", "again")) }
    fun play(t: Tile, side: Char) {
        client?.send(JSONObject().put("t", "play").put("tile", JSONArray(listOf(t.a, t.b))).put("side", side.toString()))
    }

    override fun onCleared() { cleanup() }
}
