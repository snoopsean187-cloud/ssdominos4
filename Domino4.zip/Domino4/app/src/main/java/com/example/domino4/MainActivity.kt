package com.example.domino4

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

private val Felt = Color(0xFF0B5D3B)
private val Gold = Color(0xFFFFD54F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFFC107), onPrimary = Color.Black)) {
                Surface(Modifier.fillMaxSize(), color = Felt, contentColor = Color.White) { App() }
            }
        }
    }
}

@Composable
fun App(vm: GameViewModel = viewModel()) {
    Box(Modifier.systemBarsPadding()) {
        when (vm.screen) {
            Screen.MENU -> MenuScreen(vm)
            Screen.LOBBY -> LobbyScreen(vm)
            Screen.GAME -> GameScreen(vm)
        }
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedBorderColor = Color.White, unfocusedBorderColor = Color(0xFFB0C4BB),
    focusedLabelColor = Color.White, unfocusedLabelColor = Color(0xFFB0C4BB), cursorColor = Color.White,
)

@Composable
fun MenuScreen(vm: GameViewModel) {
    var joining by remember { mutableStateOf(false) }
    var ip by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Domino 4 joueurs", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Un téléphone par joueur, tous sur le même Wi-Fi.")
        OutlinedTextField(
            value = vm.name, onValueChange = { vm.name = it.take(14) },
            label = { Text("Ton prénom") }, singleLine = true, colors = fieldColors(),
            modifier = Modifier.fillMaxWidth(),
        )
        vm.error?.let { Text(it, color = Color(0xFFFFB4AB)) }
        Button(onClick = { vm.host() }, Modifier.fillMaxWidth()) { Text("Créer une partie") }
        OutlinedButton(onClick = { joining = true; vm.startSearch() }, Modifier.fillMaxWidth()) {
            Text("Rejoindre une partie")
        }
        if (joining) {
            if (vm.found.isEmpty()) Text("Recherche des parties sur le Wi-Fi…")
            vm.found.forEach { (label, host) ->
                Button(onClick = { vm.join(host) }, Modifier.fillMaxWidth()) { Text("Rejoindre la partie de $label") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = ip, onValueChange = { ip = it },
                label = { Text("Ou adresse IP de l'hôte") }, singleLine = true, colors = fieldColors(),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(onClick = { vm.join(ip.trim()) }, enabled = ip.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text("Rejoindre par IP")
            }
        }
    }
}

@Composable
fun LobbyScreen(vm: GameViewModel) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Salon (${vm.lobbyNames.size}/4)", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        vm.lobbyNames.forEachIndexed { i, n -> Text("${i + 1}. $n" + if (i == 0) "  (hôte)" else "", fontSize = 20.sp) }
        if (vm.isHost) {
            vm.hostIp?.let { Text("Les autres joueurs te trouvent automatiquement. Sinon, ton IP : $it") }
            Button(onClick = { vm.startGame() }, enabled = vm.lobbyNames.size == 4, modifier = Modifier.fillMaxWidth()) {
                Text(if (vm.lobbyNames.size == 4) "Démarrer la partie" else "En attente de joueurs…")
            }
        } else Text("En attente du démarrage par l'hôte…")
        TextButton(onClick = { vm.leave() }) { Text("Quitter") }
    }
}

@Composable
fun GameScreen(vm: GameViewModel) {
    val s = vm.st ?: return
    val myTurn = s.turn == s.you && !s.over
    var pending by remember { mutableStateOf<Tile?>(null) }
    val left = s.board.firstOrNull()?.a
    val right = s.board.lastOrNull()?.b

    fun sides(t: Tile): List<Char> {
        if (s.board.isEmpty()) return if (t == Tile(6, 6)) listOf('R') else emptyList()
        val r = mutableListOf<Char>()
        if (t.a == left || t.b == left) r.add('L')
        if (t.a == right || t.b == right) r.add('R')
        return r
    }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            for (i in 1..3) {
                val seat = (s.you + i) % 4
                Badge(s.names[seat], s.counts[seat], s.wins[seat], s.turn == seat && !s.over)
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (s.over) s.msg else if (myTurn) "À toi de jouer !" else "Tour de ${s.names[s.turn]}",
                fontSize = 20.sp, fontWeight = FontWeight.Bold,
            )
            if (!s.over && s.msg.contains("passe")) Text(s.msg, fontSize = 13.sp)
            val scroll = rememberScrollState()
            LaunchedEffect(s.board.size) { scroll.animateScrollTo(scroll.maxValue / 2) }
            Box(Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
                Row(Modifier.horizontalScroll(scroll), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    s.board.forEach { DominoTile(it, false, 36.dp) }
                }
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)) {
                s.hand.forEach { t ->
                    val ok = myTurn && sides(t).isNotEmpty()
                    DominoTile(
                        t, true, 40.dp,
                        Modifier
                            .alpha(if (!myTurn || ok) 1f else 0.4f)
                            .then(if (ok) Modifier.border(3.dp, Gold, RoundedCornerShape(8.dp)) else Modifier)
                            .clickable(enabled = ok) {
                                val sd = sides(t)
                                if (sd.size == 1 || left == right) vm.play(t, sd[0]) else pending = t
                            },
                    )
                }
            }
            if (s.over) {
                if (vm.isHost) Button(onClick = { vm.again() }) { Text("Nouvelle manche") }
                else Text("En attente de l'hôte pour la manche suivante…")
            }
            TextButton(onClick = { vm.leave() }) { Text("Quitter la partie") }
        }
    }

    pending?.let { t ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Quel côté ?") },
            confirmButton = { TextButton(onClick = { vm.play(t, 'L'); pending = null }) { Text("Gauche ($left)") } },
            dismissButton = { TextButton(onClick = { vm.play(t, 'R'); pending = null }) { Text("Droite ($right)") } },
        )
    }
}

@Composable
fun Badge(name: String, count: Int, wins: Int, active: Boolean) {
    Column(
        Modifier.border(2.dp, if (active) Gold else Color.Transparent, RoundedCornerShape(10.dp)).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(name, fontWeight = FontWeight.Bold)
        Text("$count tuiles", fontSize = 13.sp)
        Text("\uD83C\uDFC6 $wins", fontSize = 13.sp)
    }
}

private fun pipsFor(v: Int): List<Pair<Int, Int>> = when (v) {
    1 -> listOf(1 to 1)
    2 -> listOf(0 to 0, 2 to 2)
    3 -> listOf(0 to 0, 1 to 1, 2 to 2)
    4 -> listOf(0 to 0, 2 to 0, 0 to 2, 2 to 2)
    5 -> listOf(0 to 0, 2 to 0, 0 to 2, 2 to 2, 1 to 1)
    6 -> listOf(0 to 0, 0 to 1, 0 to 2, 2 to 0, 2 to 1, 2 to 2)
    else -> emptyList()
}

private fun DrawScope.drawHalf(v: Int, ox: Float, oy: Float, s: Float) {
    pipsFor(v).forEach { (c, r) ->
        drawCircle(Color(0xFF222222), s * 0.075f, Offset(ox + s * (0.25f + 0.25f * c), oy + s * (0.25f + 0.25f * r)))
    }
}

@Composable
fun DominoTile(t: Tile, vertical: Boolean, side: Dp, modifier: Modifier = Modifier) {
    val w = if (vertical) side else side * 2
    val h = if (vertical) side * 2 else side
    Canvas(modifier.size(w, h)) {
        val s = size.minDimension
        val r = CornerRadius(s * 0.2f, s * 0.2f)
        drawRoundRect(Color(0xFFFAF7EE), cornerRadius = r)
        drawRoundRect(Color(0x66000000), cornerRadius = r, style = Stroke(1.5.dp.toPx()))
        val lw = 2.dp.toPx()
        if (vertical) {
            drawLine(Color.Gray, Offset(s * 0.12f, s), Offset(s * 0.88f, s), lw)
            drawHalf(t.a, 0f, 0f, s); drawHalf(t.b, 0f, s, s)
        } else {
            drawLine(Color.Gray, Offset(s, s * 0.12f), Offset(s, s * 0.88f), lw)
            drawHalf(t.a, 0f, 0f, s); drawHalf(t.b, s, 0f, s)
        }
    }
}
